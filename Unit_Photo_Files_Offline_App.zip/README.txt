UNIT PHOTO FILES — OFFLINE APP

Files:
- index.html: the app
- manifest.json: installable PWA settings
- sw.js: offline cache
- icon.svg: home-screen icon

Important:
This is an offline-capable web app/PWA, not a native APK. For installation from a browser, upload these files to an HTTPS static host (for example GitHub Pages). Open the hosted URL in Chrome and choose "Install app" or "Add to Home screen". Open it once online so the app shell is cached; photos and notes are saved locally on the device using IndexedDB/localStorage. Browser support and storage clearing policies may vary. Export Backup regularly to protect your data.
